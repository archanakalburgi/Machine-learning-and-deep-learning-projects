#  Company    : Stevens 
#  Project    : R Bootcamp 
#  Purpose    : symbol, value pair 
#  First Name  : Khasha
#  Last Name	: Dehnad
#  Id			    : 12345
#  Date       :
#  Comments   :

rm(list=ls())
#################################################
##   Step:
##        
##       
#################################################

myfirstname<-"Khasha"
myfirstname
mylastname<- "Dehnad"
mylastname


myfirstlast<-c( myfirstname,mylastname)
myfirstlast 

rm("myfirstname")
myfirstname
myfirstlast

myfirstname<-"Jack"


myfirstlast



myfirstname<-"Khasha"
myfirstname
mylastname<- "Dehnad"
mylastname
myfirstlast<-c( myfirstname,myfirstname)
myfirstlast 

myfirstname<-"mynewfirstname"
myfirstname
myfirstlast



