#################################################
#  Company    : Stevens 
#  Project    : R Bootcamp 
#  Purpose    : subset
#  First Name  : Khasha
#  Last Name  : Dehnad
#  Id			    : 12345
#  Date       :
#  Comments   :
rm(list=ls())

#################################################
##   Step:
##    [[]]
##     []
##
##
##
##
##
##
##
##
##
##
######################

#temp<- as.data.frame(installed.packages())

avector<-c(1,2,3,4)
typeof(avector)
second<-avector[2]
names(avector)<-c("first","second","third","fourth" )
second<-avector["second"]

avector
avector[2]<-22 
avector


my.lst <- list(34453, c("Khasha", "Dehand"), c(14.3,12,15,19))
my.lst[2]
typeof(my.lst[2])

my.lst[2]
my.lst3<-my.lst[[2]] 
typeof(my.lst3)
is.vector(my.lst3)
my.lst3[1]

my.lst
str(my.lst)

is.list(my.lst[2])
my.lst
element2<-my.lst[[2]] 
is.list(element2)
is.vector(element2)
ln<-my.lst[[2]][2]


typeof(element2)
is.list(element2)
is.vector(element2)
last_name<-my.lst[[2]][2] 

data()
data(iris)
View(iris)
iris[4,3]
iris[,]
temp1<-iris[,-3]
temp2<-iris[-3,]
temp<-iris[c(13,5,10),c(5,2,4)]

tridcol_allrows<-iris[,-3]
iris[3,]

subset4<-iris[c(T,F,F,F),]

subset1<-iris[-c(5,1,20,23),-5]

subset2<-iris[100:120,]

subset3<-iris[c(T,F,F,F,F),c(2,3,4)]
#stopped here

indx<-2:20

subset2<-iris[-indx,-5]

subset1<-iris[c(1,2,5,8), ]
subset3<-iris[-c(1,2,5,8), ]
subset4<-iris[c(T,F),]

subset2<-iris[c(T,F),c(2,3,4)]

name <- file.choose()
dsn <-  read.csv(name)
  
View(dsn)

table(Class=dsn$Class,Survival=dsn$Survived)
ftable(Class=dsn$Class,Sex=dsn$Sex,Age=dsn$Age, Survived=dsn$Survived)

Sex
dsn$Sex
attach(dsn)
Sex
Sex<-c("Yes","No")
rm("Sex")
detach(dsn)
## again error appears 
Sex
iris
attach(iris)
Sepal.Width
iris$Sepal.Width
iris[[1]]
detach(iris)

Sepal.Width<-'this is a test'
rm("Sepal.Width")

data("iris")
View(iris)
?sample
sample(100:200,50)
sample(150,97)
nrow(iris) # number of rown in the data frame 

idx<-sample(nrow(iris),as.integer(.65*nrow(iris))) # gives random sample of the data 

training<-iris[idx,] # 65% of the data is training data 
test<-iris[-idx,] # test data 


idx<-seq(1,nrow(iris),5)

training<-iris[-idx,]
test<-iris[idx,]






new_agi_stub<-income_zip[is.na(income_zip$agi_stub)==FALSE,"agi_stub" ]

#<-cbind(,)
#<-rbind(pcs1,mcs1)
#typeof()
#is.data.frame()
#is.matrix()
#<-as.data.frame(cbind( ,)) 


indx<-seq(from=1, to=nrow(iris), by=5)

test<-iris[indx,]
training<-iris[-indx,]

data("iris")
View(iris)
?subset()
hist(iris$Sepal.Length)
summary(iris$Sepal.Length)
iris_subset<-subset(iris,Sepal.Length<6.4,select = -Species)
length(iris)
nrow(iris)