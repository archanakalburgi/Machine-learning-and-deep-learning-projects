rm(list=ls())

#################################################
#  name : Archana Kalburgi  
#  CWID : 10469491
# Mid-term Solution #4
#################################################

rm(list=ls())


covid <- read.csv("/Users/archanakalburgi/Downloads/COVID19_test.csv", na.strings = c("?"))
#covid[,2:7][covid[,2:7]=="?"] <- NA
covid[,1:4][covid[,1:4]=="?"] <- NA
View(covid)


# covid <- na.omit(covid[,2:7])
covid <- na.omit(covid[,1:4])


library(kknn)
mmnorm <-function(x,minx,maxx) {z<- ((x-minx)/(maxx-minx))
return(z) 
}

#covid_normalized<-as.data.frame (         
#  cbind( Age=mmnorm(covid[,1],min(covid[,1]),max(covid[,1])) 
#        ,Exposure=mmnorm(covid[,2],min(covid[,2]),max(covid[,2]))
#       ,MaritalStatus = as.character(covid[,3])
#      ,Cases=mmnorm(covid[,4],min(covid[,4]),max(covid[,4]))
#     ,MonthAtHospital=mmnorm(covid[,5],min(covid[,5]),max(covid[,5]))
#    ,Infected=as.character(covid[,6])
#))

covid_normalized<-as.data.frame (         
  cbind(  Exposure=mmnorm(covid[,1],min(covid[,1]),max(covid[,1]))
          ,MaritalStatus = as.character(covid[,2])
          ,MonthAtHospital=mmnorm(covid[,3],min(covid[,3]),max(covid[,3]))
          ,Infected=as.character(covid[,4])
  ))

#covid_normalized$Age <- as.numeric(covid_normalized$Age)
#covid_normalized$Exposure <- as.numeric(covid_normalized$Exposure)
#covid_normalized$Cases <- as.numeric(covid_normalized$Cases)
#covid_normalized$MonthAtHospital <- as.numeric(covid_normalized$MonthAtHospital)
#covid_normalized$MaritalStatus <- factor(covid_normalized$MaritalStatus, levels = c("Married", "Single","Divorced"))
#covid_normalized$Infected <- factor(covid_normalized$Infected, levels = c("Yes", "No"))



covid_normalized$Exposure <- as.numeric(covid_normalized$Exposure)
covid_normalized$MonthAtHospital <- as.numeric(covid_normalized$MonthAtHospital)
covid_normalized$MaritalStatus <- factor(covid_normalized$MaritalStatus, levels = c("Married", "Single","Divorced"))
covid_normalized$Infected <- factor(covid_normalized$Infected, levels = c("Yes", "No"))
covid_normalized <- na.omit(covid_normalized[,1:4])
View(covid_normalized)

# write.csv(covid_normalized, file = "/Users/archanakalburgi/Downloads/KDD-midterm_Solutions/verify/covid_normalized.csv")


# index <- seq(1,nrow(covid_normalized ),by=5)

#test<-covid_normalized[index,]
#training <-covid_normalized[-index,]

training = covid_normalized

test_normalized = read.csv("/Users/archanakalburgi/Downloads/COVID19_test_test.csv") 

test_normalized$MaritalStatus <- factor(test_normalized$MaritalStatus, levels = c("Married", "Single","Divorced"))
test_normalized$Infected <- factor(test_normalized$Infected, levels = c("Yes", "No"))

# predict_k5<-kknn(formula = Infected ~ ., train = training, test[,-5],  k=5, kernel ="rectangular" )
predict_k5<-kknn(formula = Infected ~ ., train = training, test_normalized[,-4],  k=4, kernel ="rectangular" )

fit <- fitted(predict_k5)
# cm <- table(Actual=test$Infected,Fitted=fit)

cm <- table(Actual=test_normalized$Infected,Fitted=fit)

wrong<- ( test_normalized$Infected!=fit)
rate<-sum(wrong)/length(wrong)
rate

accuracy <- sum(diag(cm))/sum(cm)
accuracy