rm(list=ls())

#################################################
#  name : Archana Kalburgi  
#  CWID : 10469491
#  Homework 2 

rm(list=ls())

#################################################

# Problem 1 : Load the "breast-cancer-wisconsin.data.csv" to R

#name <- file.choose()

Cancer <- read.csv("~/Downloads/breast-cancer-wisconsin.data.csv", na.strings = c("?"))
View(Cancer)
is.data.frame(Cancer)

# Problem 1 - I. Summarizing each column 

minimum <- apply(Cancer, 2, min, na.rm = TRUE) 
minimum

maximum <- apply(Cancer, 2, max, na.rm = TRUE)
maximum

mean_of_data <- apply(Cancer, 2, mean, na.rm = TRUE)
#mean_of_data_rounded <- apply(mean_of_data, round, 2)
mean_of_data

summary(Cancer)


# Problem 1 - II Identifying missing values 

missing_values <- is.na(Cancer) # are there any missing values
missing_values

missing = apply(is.na(Cancer), 1, sum) # which rows have the missing values
missing

missing_values_columns <- colSums(is.na(Cancer)) # which columns have how many missing values
missing_values_columns

missing_values_total <- sum(is.na(Cancer)) # total number of missing values in the dataset 
missing_values_total


# Problem 1 - IV.	Displaying the frequency table of "Class" vs. F6

required_table <- table(Cancer$Class, Cancer$F6)
ftable(required_table)

